<?php

namespace Iyzipay\Model;

class Locale
{
    const TR = "tr";
    const EN = "en";
}
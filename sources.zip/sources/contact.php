<?php 
$music->site_title = lang("Contact");
$music->site_description = $music->config->description;
$music->site_pagename = "contact";
$music->site_content = loadPage("contact/content");
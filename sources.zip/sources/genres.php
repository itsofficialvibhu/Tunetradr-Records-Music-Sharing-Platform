<?php 
$music->site_title = lang('Genres');
$music->site_description = $music->config->description;
$music->site_pagename = "genres";
$music->site_content = loadPage("genres/content");